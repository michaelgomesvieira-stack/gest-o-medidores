# Dashboard de Medidores

Painel estático (HTML + CSS + JavaScript puro, sem build) para gestão de medidores novos e retirados de campo — PDT · BDC · PDS.

## Estrutura

```
.
├── index.html        # marcação da página
├── css/
│   └── style.css     # estilos (tema claro/escuro)
├── js/
│   ├── data.js       # dados iniciais embutidos (DN = novos, DR = retirados)
│   └── app.js        # lógica: filtros, gráficos, tabela, importação .xlsx
├── vercel.json       # configuração de deploy na Vercel
├── package.json      # metadados e atalho `npm run dev`
├── .vercelignore
├── .gitignore
└── README.md
```

## Rodar localmente

```bash
npx serve .
# ou: python3 -m http.server 8000
```

Abra `http://localhost:3000` (ou `:8000`). Também funciona abrindo o `index.html` direto no navegador.

## Publicar

### GitHub

```bash
git init
git add .
git commit -m "Dashboard de Medidores"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/dashboard-medidores.git
git push -u origin main
```

> Use um repositório **privado**: `js/data.js` contém nomes de responsáveis e dados operacionais.

### Vercel

**Pelo painel (recomendado)**
1. Acesse https://vercel.com/new e importe o repositório do GitHub.
2. As configurações já vêm do `vercel.json` (sem framework, sem build, saída na raiz). Não precisa alterar nada.
3. Clique em **Deploy**. Cada `git push` na `main` gera um novo deploy, e cada branch/PR ganha uma URL de preview.

**Pela CLI**
```bash
npm i -g vercel
vercel login
vercel          # preview
vercel --prod   # produção
```

**Proteger o acesso:** em *Project → Settings → Deployment Protection* ative *Vercel Authentication* (ou senha, nos planos que permitem) para que só pessoas autorizadas vejam o painel.

### GitHub Pages (alternativa)

*Settings → Pages → Deploy from a branch → `main` / `(root)`*.

## Como os dados funcionam

- **Importar planilha (.xlsx):** lê a aba `MD.*DISP` (novos) ou `MED-TRIA` (retirados). Usa SheetJS via CDN (cdnjs).
- **Salvar:** grava apenas no navegador de quem clicou (`localStorage`).
- **Atualizar os dados para todos:** substitua o conteúdo de `js/data.js` e faça commit/push.

## Limitações

- A senha de importação (`PW` em `js/app.js`) fica no código do cliente: evita cliques acidentais, mas não é segurança real.
- Para dados compartilhados entre usuários e senha de verdade, é preciso um backend (Supabase, Vercel KV, Firebase etc.).
