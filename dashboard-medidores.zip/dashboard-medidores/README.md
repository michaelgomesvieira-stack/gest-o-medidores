# Dashboard de Medidores

Painel estático (HTML + CSS + JavaScript, sem build) para gestão de medidores novos e retirados de campo — PDT · BDC · PDS.

## Estrutura

```
index.html   # aplicação completa (dados iniciais embutidos)
vercel.json  # configuração de deploy na Vercel
.gitignore
README.md
```

## Rodar localmente

Abra o `index.html` no navegador, ou sirva a pasta:

```bash
npx serve .
```

## Publicar no GitHub

```bash
git init
git add .
git commit -m "Dashboard de Medidores"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/dashboard-medidores.git
git push -u origin main
```

> Use um repositório **privado**: o arquivo contém nomes de responsáveis e dados operacionais.

## Publicar na Vercel

1. Acesse https://vercel.com/new e importe o repositório.
2. **Framework Preset:** `Other`. Deixe *Build Command* e *Output Directory* em branco.
3. Clique em **Deploy**. Cada `git push` na `main` gera um novo deploy.

Ou pela CLI: `npm i -g vercel && vercel --prod`

## Como os dados funcionam fora do Claude

- **Importar planilha (.xlsx):** abas `MD.*DISP` (novos) e `MED-TRIA` (retirados). Usa a biblioteca SheetJS via CDN (cdnjs).
- **Salvar:** fora do claude.ai grava **apenas no navegador** de quem salvou (`localStorage`). Os outros usuários continuam vendo os dados embutidos em `index.html`.
- Para atualizar os dados de **todos**, importe a planilha, e atualize as constantes `DN` e `DR` no `index.html` (ou migre para um backend, ver abaixo) e faça o commit.

## Limitações conhecidas

- A senha de importação (`PW`) está no código do cliente: serve só para evitar cliques acidentais, não é segurança real.
- Para dados compartilhados e senha de verdade, use um backend (ex.: Vercel KV/Postgres, Supabase ou Firebase) e autenticação.
